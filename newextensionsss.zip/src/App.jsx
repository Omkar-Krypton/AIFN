import { useEffect, useState } from "react";

function App() {
  const [list, setList] = useState([]);

  useEffect(() => {
    const listener = (msg) => {
      if (msg?.source !== "API_INTERCEPTOR") return;

      // store everything if you want (optional)
      setList((prev) => [
        {
          type: msg.kind,
          url: msg.url,
          status: msg.status,
          data: msg.data
        },
        ...prev
      ]);

      // ✅ FILTER: only jsprofile API with uniqueId
      const isJsProfileApi =
        typeof msg.url === "string" &&
        (msg.url.includes("recruiter-js-profile-services") || msg.url.includes("candidates")) ||
        msg.data ||
        msg.data.uniqueId;

      if (!isJsProfileApi) return;

      console.log("✅ JS PROFILE DATA FOUND:", msg.data);

      // optional local storage
      localStorage.setItem("jsProfileData", JSON.stringify(msg.data));

      // 🔥 SEND DATA TO BACKEND
      sendCandidateData(msg.data);
    };

    chrome.runtime.onMessage.addListener(listener);

    return () => {
      chrome.runtime.onMessage.removeListener(listener);
    };
  }, []);

  const sendCandidateData = async (data) => {
    try {
      const res = await fetch(
        "http://localhost:5001/api/candidate-intercept-data",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            accept: "application/json"
          },
          body: JSON.stringify(data)
        }
      );

      const result = await res.json();
      console.log("✅ Sent to backend:", result);
    } catch (err) {
      console.error("❌ Failed to send candidate data:", err);
    }
  };

  return (
    <div style={{ padding: 10, width: 400 }}>
      <h3>API Interceptor (Read-Only)</h3>

      {list.map((item, i) => (
        <div key={i} style={{ marginBottom: 12 }}>
          <b>{item.type}</b> — {item.status}
          <div style={{ fontSize: 11 }}>{item.url}</div>

          <pre
            style={{
              background: "#111",
              color: "#0f0",
              maxHeight: 200,
              overflow: "auto",
              padding: 8
            }}
          >
            {JSON.stringify(item.data, null, 2)}
          </pre>
        </div>
      ))}
    </div>
  );
}

export default App;
